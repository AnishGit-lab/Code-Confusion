"""
PriviScan Risk Scoring Engine

Important design:

- Sector is an INTERNAL context.
- Sector is NOT a user-facing detection.
- Sector changes the contextual sensitivity of information.
- PASSWORD / API_KEY / SECRET are independent Critical overrides.
- Risk is based on:
      sensitivity
      context/sector
      exposure
      confidence
      combinations
- Final score is normalized to 0-100.
"""

from typing import Any, Dict, List


# ============================================================
# BASE SENSITIVITY
# ============================================================

BASE_SENSITIVITY = {
    "NAME": 10,
    "EMAIL": 20,
    "PHONE": 30,
    "ADDRESS": 35,

    "ID": 40,
    "GOVERNMENT_ID": 80,

    "ACCOUNT_NUMBER": 70,
    "BANK_CARD": 80,

    "PASSWORD": 100,
    "API_KEY": 100,
    "SECRET": 100,

    "FACE": 50,
}


# ============================================================
# SECTORS
# ============================================================

SECTORS = {
    "HEALTHCARE",
    "FINANCE",
    "EDUCATION",
    "BUSINESS_EMPLOYMENT",
    "GOVERNMENT_LEGAL",
    "CONSUMER_SERVICES",
    "UNKNOWN",
}


# ============================================================
# EXPOSURE
# ============================================================

EXPOSURE_MULTIPLIERS = {
    "PRIVATE": 0.80,
    "LOCAL": 0.80,

    "INTERNAL": 1.00,

    "SHARED": 1.15,

    "PUBLIC": 1.30,

    "UNKNOWN": 1.00,
}


# ============================================================
# DEFAULT CONTEXT
#
# This is intentionally 1.0.
#
# The base sensitivity remains the fundamental sensitivity.
# Sector only changes the score when the context provides a
# meaningful reason to do so.
# ============================================================

DEFAULT_CONTEXT_MULTIPLIER = 1.00


# ============================================================
# SECTOR-SPECIFIC CONTEXT
#
# Important:
#
# These are INITIAL CALIBRATION VALUES for PriviScan.
# They are not universal statistical facts.
#
# A value below 1.0 means:
# "This data is relatively expected/common in this context."
#
# A value above 1.0 means:
# "This data has additional contextual sensitivity here."
# ============================================================

SECTOR_CONTEXT = {

    "HEALTHCARE": {
        "MEDICAL": 0.80,
        "PATIENT_ID": 0.80,
        "GOVERNMENT_ID": 1.00,
        "ACCOUNT_NUMBER": 1.00,
        "BANK_CARD": 1.00,
    },

    "FINANCE": {
        "ACCOUNT_NUMBER": 1.00,
        "BANK_CARD": 1.00,
        "GOVERNMENT_ID": 1.00,
    },

    "EDUCATION": {
        "ID": 0.90,
        "STUDENT_ID": 0.80,
        "EMPLOYEE_ID": 0.90,
        "GOVERNMENT_ID": 1.00,
    },

    "BUSINESS_EMPLOYMENT": {
        "ID": 0.90,
        "EMPLOYEE_ID": 0.80,
        "GOVERNMENT_ID": 1.00,
    },

    "GOVERNMENT_LEGAL": {
        # Government IDs are expected/common in this context.
        "GOVERNMENT_ID": 0.80,

        # Other identity information can still be sensitive.
        "ID": 0.90,

        "NAME": 0.90,
        "ADDRESS": 0.90,
    },

    "CONSUMER_SERVICES": {
        "GOVERNMENT_ID": 1.10,
        "ACCOUNT_NUMBER": 1.00,
        "BANK_CARD": 1.00,
    },

    "UNKNOWN": {},
}


# ============================================================
# CRITICAL CREDENTIALS
# ============================================================

CRITICAL_TYPES = {
    "PASSWORD",
    "API_KEY",
    "SECRET",
}

CRITICAL_CONFIDENCE_THRESHOLD = 0.85


# ============================================================
# RISK LEVEL
# ============================================================

def get_risk_level(score: float) -> str:

    score = max(
        0.0,
        min(100.0, float(score)),
    )

    if score <= 20:
        return "LOW"

    if score <= 40:
        return "MEDIUM"

    if score <= 70:
        return "HIGH"

    return "CRITICAL"


# ============================================================
# NORMALIZATION
# ============================================================

def normalize_sector(sector: str) -> str:

    if not sector:
        return "UNKNOWN"

    sector = str(sector).strip().upper()

    if sector not in SECTORS:
        return "UNKNOWN"

    return sector


def normalize_exposure(exposure: str) -> str:

    if not exposure:
        return "UNKNOWN"

    exposure = str(exposure).strip().upper()

    return exposure if exposure in EXPOSURE_MULTIPLIERS else "UNKNOWN"


# ============================================================
# CONTEXT MULTIPLIER
# ============================================================

def get_context_multiplier(
    detection_type: str,
    sector: str,
    subtype: str = "",
) -> float:
    """
    Determine contextual sensitivity.

    Example:

        GOVERNMENT_ID + PRIVATE/UNKNOWN
            -> 1.00

        GOVERNMENT_ID + GOVERNMENT_LEGAL
            -> 0.80

    Therefore:

        Government ID base = 80

        Government/legal context:
            80 × 0.80 = 64

        Private/unknown context:
            80 × 1.00 = 80

    This allows the same information to have different risk
    depending on where/how it is being shared.
    """

    sector = normalize_sector(sector)

    detection_type = str(
        detection_type or ""
    ).upper()

    subtype = str(
        subtype or ""
    ).upper()

    sector_rules = SECTOR_CONTEXT.get(
        sector,
        {},
    )

    # Most specific subtype first.
    if subtype and subtype in sector_rules:
        return sector_rules[subtype]

    # Then detection type.
    if detection_type in sector_rules:
        return sector_rules[detection_type]

    return DEFAULT_CONTEXT_MULTIPLIER


# ============================================================
# INDIVIDUAL RISK
# ============================================================

def calculate_detection_risk(
    detection: Dict[str, Any],
    sector: str = "UNKNOWN",
    exposure: str = "UNKNOWN",
) -> float:
    """
    Calculate risk for one detection.
    """

    detection_type = str(
        detection.get("type", "")
    ).upper()

    sensitivity = BASE_SENSITIVITY.get(
        detection_type,
        0,
    )

    if sensitivity <= 0:
        return 0.0

    confidence = float(
        detection.get(
            "confidence",
            0.0,
        )
    )

    confidence = max(
        0.0,
        min(1.0, confidence),
    )

    subtype = detection.get(
        "subtype",
        "",
    )

    context_multiplier = get_context_multiplier(
        detection_type,
        sector,
        subtype,
    )

    exposure_multiplier = EXPOSURE_MULTIPLIERS.get(
        normalize_exposure(exposure),
        1.0,
    )

    risk = (
        sensitivity
        * context_multiplier
        * exposure_multiplier
        * confidence
    )

    return round(
        min(100.0, risk),
        2,
    )


# ============================================================
# CRITICAL OVERRIDE
# ============================================================

def find_critical_detections(
    detections: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Find high-confidence credentials/secrets.
    """

    critical = []

    for detection in detections:

        detection_type = str(
            detection.get("type", "")
        ).upper()

        confidence = float(
            detection.get(
                "confidence",
                0.0,
            )
        )

        if (
            detection_type in CRITICAL_TYPES
            and confidence >= CRITICAL_CONFIDENCE_THRESHOLD
        ):
            critical.append(detection)

    return critical


def has_critical_override(
    detections: List[Dict[str, Any]],
) -> bool:

    return bool(
        find_critical_detections(
            detections
        )
    )


# ============================================================
# COMBINATION RISK
# ============================================================

def calculate_combination_risk(
    detections: List[Dict[str, Any]],
) -> float:
    """
    Calculate additional risk caused by combinations.

    This is separate from the individual sensitivity of each
    item.
    """

    types = {
        str(
            detection.get("type", "")
        ).upper()
        for detection in detections
    }

    combination_risk = 0.0

    # --------------------------------------------------------
    # NAME + EMAIL
    # --------------------------------------------------------

    if {
        "NAME",
        "EMAIL",
    }.issubset(types):

        combination_risk += 5

    # --------------------------------------------------------
    # NAME + PHONE + ADDRESS
    # --------------------------------------------------------

    if {
        "NAME",
        "PHONE",
        "ADDRESS",
    }.issubset(types):

        combination_risk += 10

    # --------------------------------------------------------
    # NAME + ACCOUNT + ADDRESS
    # --------------------------------------------------------

    if {
        "NAME",
        "ACCOUNT_NUMBER",
        "ADDRESS",
    }.issubset(types):

        combination_risk += 20

    # --------------------------------------------------------
    # NAME + ID
    # --------------------------------------------------------

    if {
        "NAME",
        "ID",
    }.issubset(types):

        combination_risk += 15

    # --------------------------------------------------------
    # NAME + GOVERNMENT ID
    # --------------------------------------------------------

    if {
        "NAME",
        "GOVERNMENT_ID",
    }.issubset(types):

        combination_risk += 20

    # --------------------------------------------------------
    # NAME + BANK CARD
    # --------------------------------------------------------

    if {
        "NAME",
        "BANK_CARD",
    }.issubset(types):

        combination_risk += 20

    # --------------------------------------------------------
    # Many identity attributes
    # --------------------------------------------------------

    identity_types = {
        "NAME",
        "EMAIL",
        "PHONE",
        "ADDRESS",
        "ID",
        "GOVERNMENT_ID",
        "ACCOUNT_NUMBER",
    }

    identity_count = len(
        types.intersection(
            identity_types
        )
    )

    if identity_count >= 4:
        combination_risk += 15

    return round(
        combination_risk,
        2,
    )


# ============================================================
# MAJOR RISK FACTORS
# ============================================================

def build_major_risk_factors(
    detections: List[Dict[str, Any]],
    sector: str,
    exposure: str,
    critical_detections: List[Dict[str, Any]],
) -> List[str]:

    factors = []

    if critical_detections:
        factors.append(
            "High-confidence credential or secret detected"
        )

    types = {
        str(
            detection.get("type", "")
        ).upper()
        for detection in detections
    }

    if "ACCOUNT_NUMBER" in types:
        factors.append(
            "Financial account information detected"
        )

    if "BANK_CARD" in types:
        factors.append(
            "Bank card information detected"
        )

    if "GOVERNMENT_ID" in types:
        if sector == "GOVERNMENT_LEGAL":
            factors.append(
                "Government ID detected in government/legal context"
            )
        else:
            factors.append(
                "Government ID detected outside government/legal context"
            )

    if len(types.intersection({
        "NAME",
        "EMAIL",
        "PHONE",
        "ADDRESS",
        "ID",
        "GOVERNMENT_ID",
        "ACCOUNT_NUMBER",
    })) >= 3:

        factors.append(
            "Multiple linked identity attributes detected"
        )

    if normalize_exposure(exposure) == "PUBLIC":
        factors.append(
            "Information is intended for public exposure"
        )

    return factors


# ============================================================
# COMPLETE RISK CALCULATION
# ============================================================

def calculate_risk(
    detections: List[Dict[str, Any]],
    sector: str = "UNKNOWN",
    exposure: str = "UNKNOWN",
) -> Dict[str, Any]:
    """
    Complete PriviScan risk calculation.

    IMPORTANT:
    Sector is used internally but is NOT intended to be
    displayed as a detection result.
    """

    sector = normalize_sector(sector)
    exposure = normalize_exposure(exposure)

    # --------------------------------------------------------
    # Credential override
    # --------------------------------------------------------

    critical_detections = (
        find_critical_detections(
            detections
        )
    )

    credential_override = bool(
        critical_detections
    )

    # --------------------------------------------------------
    # Individual risks
    # --------------------------------------------------------

    analyzed_detections = []

    individual_total = 0.0

    for detection in detections:

        item = dict(detection)

        risk = calculate_detection_risk(
            item,
            sector=sector,
            exposure=exposure,
        )

        item["risk"] = risk

        analyzed_detections.append(
            item
        )

        individual_total += risk

    # --------------------------------------------------------
    # Combination risk
    # --------------------------------------------------------

    combination_risk = (
        calculate_combination_risk(
            detections
        )
    )

    # --------------------------------------------------------
    # Final score
    # --------------------------------------------------------

    if credential_override:

        # High-confidence PASSWORD/API_KEY/SECRET
        # independently forces Critical.
        final_score = 100.0

    else:

        final_score = (
            individual_total
            + combination_risk
        )

        final_score = min(
            100.0,
            final_score,
        )

    risk_level = get_risk_level(
        final_score
    )

    # --------------------------------------------------------
    # Risk factors
    # --------------------------------------------------------

    major_risk_factors = (
        build_major_risk_factors(
            analyzed_detections,
            sector,
            exposure,
            critical_detections,
        )
    )

    return {
        # Internal context.
        # analyze.py can use this internally, but should not
        # print it as part of "detections".
        "sector": sector,

        "exposure": exposure,

        "risk_score": round(
            final_score,
            2,
        ),

        "risk_level": risk_level,

        "individual_total": round(
            individual_total,
            2,
        ),

        "combination_risk": round(
            combination_risk,
            2,
        ),

        "credential_override": credential_override,

        "critical_detections": critical_detections,

        "detections": analyzed_detections,

        "major_risk_factors": major_risk_factors,
    }


# ============================================================
# BACKWARD COMPATIBILITY
# ============================================================

def calculate_average_risk(
    detections: List[Dict[str, Any]],
) -> float:

    if not detections:
        return 0.0

    risks = []

    for detection in detections:

        risk = calculate_detection_risk(
            detection
        )

        risks.append(risk)

    return round(
        sum(risks) / len(risks),
        2,
    )