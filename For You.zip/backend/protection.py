from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Iterable

import cv2 #type: ignore
import numpy as np #type: ignore

from backend.detection.ai_detector import detect_with_ai


# ============================================================
# CONFIGURATION
# ============================================================

DEFAULT_OUTPUT_DIR = Path("uploads")

SUPPORTED_METHODS = {
    "blur",
    "blackout",
}

SUPPORTED_MODES = {
    "automatic",
    "manual",
}

# High-risk information receives stronger protection.
HIGH_RISK_TYPES = {
    "PASSWORD",
    "API_KEY",
    "SECRET",
    "ACCOUNT_NUMBER",
    "BANK_CARD",
    "GOVERNMENT_ID",
}


# ============================================================
# BOX UTILITIES
# ============================================================

def normalize_box(
    box: Any,
) -> tuple[int, int, int, int] | None:
    """
    Convert a detection box into:

        x1, y1, x2, y2

    Returns None if the box is invalid.
    """

    if box is None:
        return None

    try:
        values = list(box)
    except (TypeError, ValueError):
        return None

    if len(values) != 4:
        return None

    try:
        x1, y1, x2, y2 = [
            int(round(float(value)))
            for value in values
        ]
    except (TypeError, ValueError):
        return None

    if x2 < x1:
        x1, x2 = x2, x1

    if y2 < y1:
        y1, y2 = y2, y1

    if x2 <= x1 or y2 <= y1:
        return None

    return x1, y1, x2, y2


def expand_box(
    box: tuple[int, int, int, int],
    detection_type: str,
) -> tuple[int, int, int, int]:
    """
    Expand the original AI/OCR box slightly.

    This compensates for OCR boxes that are too tight around
    the detected text.
    """

    x1, y1, x2, y2 = box

    width = x2 - x1
    height = y2 - y1

    detection_type = detection_type.upper().strip()

    # Normal sensitive information.
    horizontal_padding = max(
        6,
        int(width * 0.02),
    )

    vertical_padding = max(
        8,
        int(height * 0.35),
    )

    # High-risk information gets additional padding.
    if detection_type in HIGH_RISK_TYPES:
        horizontal_padding = max(
            10,
            int(width * 0.04),
        )

        vertical_padding = max(
            14,
            int(height * 0.65),
        )

    return (
        x1 - horizontal_padding,
        y1 - vertical_padding,
        x2 + horizontal_padding,
        y2 + vertical_padding,
    )


def clip_box(
    box: tuple[int, int, int, int],
    image_width: int,
    image_height: int,
) -> tuple[int, int, int, int] | None:
    """
    Keep a box inside image boundaries.
    """

    x1, y1, x2, y2 = box

    x1 = max(0, min(x1, image_width))
    x2 = max(0, min(x2, image_width))

    y1 = max(0, min(y1, image_height))
    y2 = max(0, min(y2, image_height))

    if x2 <= x1 or y2 <= y1:
        return None

    return x1, y1, x2, y2


# ============================================================
# PROTECTION METHODS
# ============================================================

def apply_blur(
    image: np.ndarray,
    box: tuple[int, int, int, int],
    detection_type: str = "",
) -> None:
    """
    Apply Gaussian blur to one sensitive region.
    """

    x1, y1, x2, y2 = box

    roi = image[y1:y2, x1:x2]

    if roi.size == 0:
        return

    width = x2 - x1
    height = y2 - y1

    detection_type = detection_type.upper().strip()

    if detection_type in HIGH_RISK_TYPES:
        kernel_size = max(
            31,
            min(width, height),
        )
    else:
        kernel_size = max(
            15,
            min(width, height) // 2,
        )

    if kernel_size % 2 == 0:
        kernel_size += 1

    kernel_size = min(
        kernel_size,
        99,
    )

    if kernel_size < 3:
        kernel_size = 3

    blurred = cv2.GaussianBlur(
        roi,
        (kernel_size, kernel_size),
        0,
    )

    image[y1:y2, x1:x2] = blurred


def apply_blackout(
    image: np.ndarray,
    box: tuple[int, int, int, int],
) -> None:
    """
    Completely cover a sensitive region.
    """

    x1, y1, x2, y2 = box

    image[y1:y2, x1:x2] = 0


# ============================================================
# SINGLE DETECTION PROTECTION
# ============================================================

def protect_detection(
    image: np.ndarray,
    detection: dict[str, Any],
    method: str = "blur",
) -> bool:
    """
    Protect one sensitive detection.

    Returns True if protection was successfully applied.
    """

    method = method.lower().strip()

    if method not in SUPPORTED_METHODS:
        raise ValueError(
            f"Unsupported protection method: {method}"
        )

    detection_type = str(
        detection.get("type", "")
    ).upper().strip()

    raw_box = detection.get("box")

    box = normalize_box(raw_box)

    if box is None:
        return False

    # Expand the AI detection box.
    expanded_box = expand_box(
        box=box,
        detection_type=detection_type,
    )

    height, width = image.shape[:2]

    # Keep the expanded box inside the image.
    clipped_box = clip_box(
        expanded_box,
        image_width=width,
        image_height=height,
    )

    if clipped_box is None:
        return False

    if method == "blur":

        apply_blur(
            image=image,
            box=clipped_box,
            detection_type=detection_type,
        )

    elif method == "blackout":

        apply_blackout(
            image=image,
            box=clipped_box,
        )

    return True


# ============================================================
# DETECTION SELECTION
# ============================================================

def select_detections(
    detections: Iterable[dict[str, Any]],
    mode: str,
    selected_indices: list[int] | None = None,
) -> list[dict[str, Any]]:
    """
    Select detections for protection.

    Automatic:
        Select all detections.

    Manual:
        Select only the requested detection indexes.
    """

    mode = mode.lower().strip()

    if mode not in SUPPORTED_MODES:
        raise ValueError(
            f"Unsupported mode: {mode}"
        )

    detections = list(detections)

    if mode == "automatic":
        return detections

    if selected_indices is None:
        return []

    selected_set = set(selected_indices)

    return [
        detection
        for index, detection in enumerate(detections)
        if index in selected_set
    ]


# ============================================================
# MANUAL SELECTION
# ============================================================

def display_detection_list(
    detections: list[dict[str, Any]],
) -> None:
    """
    Display detected items for manual selection.

    Sensitive values are displayed because this is a local
    command-line protection workflow.
    """

    print()
    print("-" * 60)
    print("DETECTED SENSITIVE INFORMATION")
    print("-" * 60)

    for index, detection in enumerate(
        detections,
        start=1,
    ):

        detection_type = detection.get(
            "type",
            "UNKNOWN",
        )

        value = detection.get(
            "value",
            "",
        )

        confidence = detection.get(
            "confidence",
            0.0,
        )

        print(
            f"[{index}] {detection_type}"
        )

        print(
            f"    Value: {value}"
        )

        print(
            f"    Confidence: {confidence}"
        )

        print()


def parse_selection(
    user_input: str,
    detection_count: int,
) -> list[int]:
    """
    Convert input such as:

        1,2,5,8

    into zero-based indexes:

        [0,1,4,7]
    """

    user_input = user_input.strip()

    if not user_input:
        return []

    if user_input.lower() in {
        "all",
        "*",
    }:
        return list(
            range(detection_count)
        )

    selected = set()

    parts = user_input.split(",")

    for part in parts:

        part = part.strip()

        if not part:
            continue

        # Support ranges such as 1-4.
        if "-" in part:

            range_parts = part.split("-")

            if len(range_parts) != 2:
                raise ValueError(
                    f"Invalid selection: {part}"
                )

            start = int(
                range_parts[0].strip()
            )

            end = int(
                range_parts[1].strip()
            )

            if start > end:
                start, end = end, start

            for number in range(
                start,
                end + 1,
            ):

                if number < 1 or number > detection_count:
                    raise ValueError(
                        f"Selection {number} "
                        f"is outside the valid range."
                    )

                selected.add(
                    number - 1
                )

        else:

            number = int(part)

            if number < 1 or number > detection_count:
                raise ValueError(
                    f"Selection {number} "
                    f"is outside the valid range."
                )

            selected.add(
                number - 1
            )

    return sorted(selected)


def ask_manual_selection(
    detections: list[dict[str, Any]],
) -> list[int]:
    """
    Interactive manual detection selection.
    """

    display_detection_list(
        detections
    )

    print("-" * 60)
    print(
        "Select the items you want to protect."
    )

    print(
        "Examples: 1,2,5"
    )

    print(
        "Range example: 1-5"
    )

    print(
        "All items: all"
    )

    print(
        "Cancel: 0"
    )

    while True:

        user_input = input(
            "\nSelection: "
        ).strip()

        if user_input == "0":
            return []

        try:

            selected = parse_selection(
                user_input,
                len(detections),
            )

            return selected

        except ValueError as error:

            print(
                f"Invalid selection: {error}"
            )


def ask_protection_method() -> str:
    """
    Ask the user which protection method to use.
    """

    print()
    print("-" * 60)
    print("PROTECTION METHOD")
    print("-" * 60)

    print(
        "[1] Blur"
    )

    print(
        "[2] Blackout"
    )

    while True:

        choice = input(
            "\nChoose method [1/2]: "
        ).strip().lower()

        if choice in {
            "1",
            "blur",
        }:
            return "blur"

        if choice in {
            "2",
            "blackout",
        }:
            return "blackout"

        print(
            "Please choose 1 or 2."
        )


# ============================================================
# PROTECT IMAGE
# ============================================================

def protect_image(
    image_path: str | Path,
    detections: list[dict[str, Any]],
    mode: str = "automatic",
    method: str = "blur",
    selected_indices: list[int] | None = None,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """
    Protect sensitive regions in an image.

    Parameters
    ----------
    image_path:
        Original image.

    detections:
        AI detector results.

    mode:
        automatic or manual.

    method:
        blur or blackout.

    selected_indices:
        Zero-based indexes for manual mode.

    output_path:
        Optional output path.
    """

    image_path = Path(
        image_path
    )

    if not image_path.exists():
        raise FileNotFoundError(
            f"Image not found: {image_path}"
        )

    mode = mode.lower().strip()
    method = method.lower().strip()

    if mode not in SUPPORTED_MODES:
        raise ValueError(
            f"Unsupported mode: {mode}"
        )

    if method not in SUPPORTED_METHODS:
        raise ValueError(
            f"Unsupported method: {method}"
        )

    image = cv2.imread(
        str(image_path)
    )

    if image is None:
        raise ValueError(
            f"Could not read image: {image_path}"
        )

    selected_detections = select_detections(
        detections=detections,
        mode=mode,
        selected_indices=selected_indices,
    )

    protected_detections = []

    for detection in selected_detections:

        success = protect_detection(
            image=image,
            detection=detection,
            method=method,
        )

        if success:
            protected_detections.append(
                detection
            )

    # --------------------------------------------------------
    # Output path
    # --------------------------------------------------------

    if output_path is None:

        DEFAULT_OUTPUT_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        if mode == "manual":
            filename = (
                f"{image_path.stem}"
                f"_manual_protected"
                f"{image_path.suffix}"
            )
        else:
            filename = (
                f"{image_path.stem}"
                f"_protected"
                f"{image_path.suffix}"
            )

        output_path = (
            DEFAULT_OUTPUT_DIR
            / filename
        )

    else:

        output_path = Path(
            output_path
        )

        output_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

    output_path = Path(
        output_path
    )

    # --------------------------------------------------------
    # Save image
    # --------------------------------------------------------

    success = cv2.imwrite(
        str(output_path),
        image,
    )

    if not success:
        raise IOError(
            f"Could not save protected image: "
            f"{output_path}"
        )

    return {
        "input_image": str(
            image_path
        ),
        "output_image": str(
            output_path
        ),
        "mode": mode.upper(),
        "method": method.upper(),
        "detected_count": len(
            detections
        ),
        "selected_count": len(
            selected_detections
        ),
        "protected_count": len(
            protected_detections
        ),
        "protected_detections": (
            protected_detections
        ),
    }


# ============================================================
# RESULT DISPLAY
# ============================================================

def print_protection_result(
    result: dict[str, Any],
) -> None:

    print()
    print("=" * 60)
    print("             PRIVISCAN PROTECTION")
    print("=" * 60)

    print()
    print(
        f"Mode: {result['mode']}"
    )

    print(
        f"Method: {result['method']}"
    )

    print()
    print(
        f"Detected sensitive items: "
        f"{result['detected_count']}"
    )

    print(
        f"Selected items: "
        f"{result['selected_count']}"
    )

    print(
        f"Protected items: "
        f"{result['protected_count']}"
    )

    print()

    for index, detection in enumerate(
        result["protected_detections"],
        start=1,
    ):

        detection_type = detection.get(
            "type",
            "UNKNOWN",
        )

        value = detection.get(
            "value",
            "",
        )

        print(
            f"[{index}] {detection_type}"
        )

        print(
            f"Value: {value}"
        )

        print()

    print(
        f"Protected image: "
        f"{result['output_image']}"
    )

    print()
    print("=" * 60)


# ============================================================
# INTERACTIVE MODE
# ============================================================

def run_interactive_protection(
    image_path: Path,
    detections: list[dict[str, Any]],
) -> None:
    """
    Interactive protection workflow.

    The user chooses:
        1. Automatic
        2. Manual
    """

    print()
    print("=" * 60)
    print("          PRIVISCAN PROTECTION MODE")
    print("=" * 60)

    print()
    print(
        "[1] Automatic Protection"
    )

    print(
        "    Protect all detected sensitive information."
    )

    print()

    print(
        "[2] Manual Protection"
    )

    print(
        "    Select which detected items to protect."
    )

    while True:

        choice = input(
            "\nChoose mode [1/2]: "
        ).strip()

        if choice in {"1", "automatic"}:

            method = ask_protection_method()

            result = protect_image(
                image_path=image_path,
                detections=detections,
                mode="automatic",
                method=method,
            )

            print_protection_result(
                result
            )

            return

        if choice in {"2", "manual"}:

            selected_indices = (
                ask_manual_selection(
                    detections
                )
            )

            if not selected_indices:

                print()
                print(
                    "No items selected."
                )

                print(
                    "Protection cancelled."
                )

                return

            method = ask_protection_method()

            result = protect_image(
                image_path=image_path,
                detections=detections,
                mode="manual",
                method=method,
                selected_indices=selected_indices,
            )

            print_protection_result(
                result
            )

            return

        print(
            "Please choose 1 or 2."
        )


# ============================================================
# ARGUMENT PARSER
# ============================================================

def build_argument_parser() -> argparse.ArgumentParser:

    parser = argparse.ArgumentParser(
        description=(
            "PriviScan sensitive-data "
            "protection system."
        )
    )

    parser.add_argument(
        "image",
        help="Path to the input image.",
    )

    parser.add_argument(
        "--mode",
        choices=[
            "automatic",
            "manual",
            "interactive",
        ],
        default="interactive",
        help=(
            "Protection mode. "
            "Default: interactive."
        ),
    )

    parser.add_argument(
        "--method",
        choices=[
            "blur",
            "blackout",
        ],
        default="blur",
        help=(
            "Protection method. "
            "Default: blur."
        ),
    )

    parser.add_argument(
        "--select",
        default=None,
        help=(
            "Manual selection. "
            "Example: 1,2,5 or 1-5."
        ),
    )

    parser.add_argument(
        "--output",
        default=None,
        help=(
            "Optional output image path."
        ),
    )

    return parser


# ============================================================
# COMMAND-LINE MAIN
# ============================================================

def main() -> None:

    parser = build_argument_parser()

    args = parser.parse_args()

    image_path = Path(
        args.image
    )

    if not image_path.exists():

        print(
            f"ERROR: Image not found: "
            f"{image_path}"
        )

        sys.exit(1)

    # --------------------------------------------------------
    # AI detection
    # --------------------------------------------------------

    print()
    print(
        "[1/2] Detecting sensitive information..."
    )

    detections = detect_with_ai(
        image_path
    )

    print()
    print(
        f"AI detected {len(detections)} "
        f"sensitive items."
    )

    if not detections:

        print()
        print(
            "No sensitive information detected."
        )

        return

    # --------------------------------------------------------
    # Interactive protection
    # --------------------------------------------------------

    if args.mode == "interactive":

        run_interactive_protection(
            image_path=image_path,
            detections=detections,
        )

        return

    # --------------------------------------------------------
    # Automatic
    # --------------------------------------------------------

    if args.mode == "automatic":

        print()
        print(
            "[2/2] Applying automatic protection..."
        )

        output_path = (
            Path(args.output)
            if args.output
            else None
        )

        result = protect_image(
            image_path=image_path,
            detections=detections,
            mode="automatic",
            method=args.method,
            output_path=output_path,
        )

        print_protection_result(
            result
        )

        return

    # --------------------------------------------------------
    # Manual command-line mode
    # --------------------------------------------------------

    if args.mode == "manual":

        if args.select is None:

            selected_indices = (
                ask_manual_selection(
                    detections
                )
            )

        else:

            try:

                selected_indices = (
                    parse_selection(
                        args.select,
                        len(detections),
                    )
                )

            except ValueError as error:

                print(
                    f"ERROR: {error}"
                )

                sys.exit(1)

        if not selected_indices:

            print()
            print(
                "No items selected."
            )

            return

        output_path = (
            Path(args.output)
            if args.output
            else None
        )

        result = protect_image(
            image_path=image_path,
            detections=detections,
            mode="manual",
            method=args.method,
            selected_indices=selected_indices,
            output_path=output_path,
        )

        print_protection_result(
            result
        )

        return


if __name__ == "__main__":
    main()