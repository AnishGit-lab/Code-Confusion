from pathlib import Path
from uuid import uuid4
import html
import shutil

from fastapi import (
    FastAPI,
    UploadFile,
    File,
    Form,
)

from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from backend.analyze import analyze_image
from backend.protection import protect_image


# ============================================================
# APP
# ============================================================

app = FastAPI(
    title="PriviScan"
)


# ============================================================
# DIRECTORIES
# ============================================================

UPLOAD_DIR = Path("uploads")

UPLOAD_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


app.mount(
    "/uploads",
    StaticFiles(
        directory=str(UPLOAD_DIR)
    ),
    name="uploads",
)


# ============================================================
# HTML HELPERS
# ============================================================

def page_style() -> str:
    return """
    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            color: #222;
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 8px;
        }

        h2 {
            margin-top: 0;
        }

        h3 {
            margin-bottom: 10px;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 35px;
        }

        .card {
            background: white;
            border-radius: 14px;
            padding: 25px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
        }

        .upload-box {
            border: 2px dashed #999;
            border-radius: 14px;
            padding: 45px 25px;
            text-align: center;
            background: white;
        }

        input[type="file"] {
            margin: 20px 0;
            font-size: 16px;
        }

        button {
            background: #222;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            opacity: 0.85;
        }

        .summary {
            text-align: center;
        }

        .risk-score {
            font-size: 42px;
            font-weight: bold;
            margin: 10px 0;
        }

        .risk-level {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .critical {
            color: #b00020;
        }

        .high {
            color: #d46b00;
        }

        .medium {
            color: #9a7800;
        }

        .low {
            color: #237a3b;
        }

        .detection {
            border: 1px solid #ddd;
            border-radius: 12px;
            padding: 18px;
            margin: 12px 0;
            background: #fafafa;
        }

        .detection-header {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .detection-type {
            font-size: 19px;
            font-weight: bold;
        }

        .detection-value {
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 8px;
            margin-top: 10px;
            word-break: break-word;
        }

        .protection-box {
            border: 2px solid #888;
            border-radius: 14px;
            padding: 25px;
            margin-top: 30px;
            background: white;
        }

        .option {
            display: block;
            margin: 12px 0;
            font-size: 17px;
            cursor: pointer;
        }

        .method-box {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
        }

        select {
            padding: 10px;
            font-size: 16px;
            border-radius: 7px;
            border: 1px solid #aaa;
            min-width: 180px;
        }

        .note {
            color: #666;
            font-size: 14px;
            margin-top: 10px;
        }

        .image-preview {
            text-align: center;
        }

        .image-preview img {
            max-width: 100%;
            max-height: 700px;
            border-radius: 10px;
            border: 1px solid #ddd;
            margin-top: 20px;
        }

        .center {
            text-align: center;
        }

        a {
            color: #333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            background: #fff0f0;
            border: 1px solid #e0a0a0;
            border-radius: 10px;
            padding: 20px;
        }

    </style>
    """


def risk_class(level: str) -> str:
    """
    Convert risk level to a CSS class.
    """

    level = str(level).upper()

    if level == "CRITICAL":
        return "critical"

    if level == "HIGH":
        return "high"

    if level == "MEDIUM":
        return "medium"

    return "low"


# ============================================================
# HOME
# ============================================================

@app.get(
    "/",
    response_class=HTMLResponse,
)
async def home():

    return f"""
    <!DOCTYPE html>

    <html>

    <head>

        <title>PriviScan</title>

        {page_style()}

    </head>

    <body>

        <h1>
            PriviScan
        </h1>

        <p class="subtitle">
            Intelligent Privacy Risk Assessment
            and Sensitive Information Protection
        </p>

        <div class="upload-box">

            <h2>
                Upload an Image
            </h2>

            <p>
                PriviScan will detect sensitive
                information and calculate privacy risk.
            </p>

            <form
                action="/analyze"
                method="post"
                enctype="multipart/form-data"
            >

                <input
                    type="file"
                    name="file"
                    accept="image/*"
                    required
                >

                <br>

                <button type="submit">
                    Analyze Image
                </button>

            </form>

        </div>

    </body>

    </html>
    """


# ============================================================
# ANALYZE IMAGE
# ============================================================

@app.post(
    "/analyze",
    response_class=HTMLResponse,
)
async def analyze(
    file: UploadFile = File(...),
):

    # --------------------------------------------------------
    # Validate image
    # --------------------------------------------------------

    if (
        not file.content_type
        or not file.content_type.startswith("image/")
    ):

        return f"""
        <!DOCTYPE html>

        <html>

        <head>
            <title>PriviScan Error</title>
            {page_style()}
        </head>

        <body>

            <div class="error">

                <h1>
                    Invalid File
                </h1>

                <p>
                    Please upload a JPG, JPEG, PNG,
                    or another supported image.
                </p>

                <a href="/">
                    ← Go Back
                </a>

            </div>

        </body>

        </html>
        """

    # --------------------------------------------------------
    # Safe filename
    # --------------------------------------------------------

    original_name = Path(
        file.filename or "image"
    ).name

    stored_name = (
        uuid4().hex
        + "_"
        + original_name
    )

    file_path = (
        UPLOAD_DIR
        / stored_name
    )

    # --------------------------------------------------------
    # Save uploaded image
    # --------------------------------------------------------

    try:

        with file_path.open("wb") as buffer:

            shutil.copyfileobj(
                file.file,
                buffer,
            )

    except Exception as error:

        return f"""
        <!DOCTYPE html>

        <html>

        <head>
            <title>PriviScan Error</title>
            {page_style()}
        </head>

        <body>

            <div class="error">

                <h1>
                    Upload Error
                </h1>

                <p>
                    {html.escape(str(error))}
                </p>

                <a href="/">
                    ← Try Again
                </a>

            </div>

        </body>

        </html>
        """

    # --------------------------------------------------------
    # Analyze
    # --------------------------------------------------------

    try:

        analysis = analyze_image(
            str(file_path)
        )

    except Exception as error:

        return f"""
        <!DOCTYPE html>

        <html>

        <head>
            <title>PriviScan Error</title>
            {page_style()}
        </head>

        <body>

            <div class="error">

                <h1>
                    PriviScan Analysis Error
                </h1>

                <p>
                    {html.escape(str(error))}
                </p>

                <a href="/">
                    ← Try Again
                </a>

            </div>

        </body>

        </html>
        """

    # --------------------------------------------------------
    # Get analysis results
    # --------------------------------------------------------

    detections = analysis.get(
        "detections",
        [],
    )

    risk_score = float(
        analysis.get(
            "risk_score",
            0.0,
        )
    )

    risk_level = str(
        analysis.get(
            "risk_level",
            "LOW",
        )
    )

    risk = analysis.get(
        "risk",
        {},
    )

    combination_risk = float(
        risk.get(
            "combination_risk",
            0.0,
        )
    )

    critical_override = bool(
        risk.get(
            "credential_override",
            False,
        )
    )

    # --------------------------------------------------------
    # Risk CSS
    # --------------------------------------------------------

    risk_css = risk_class(
        risk_level
    )

    # ========================================================
    # RESULT PAGE
    # ========================================================

    page = f"""
    <!DOCTYPE html>

    <html>

    <head>

        <title>
            PriviScan Analysis
        </title>

        {page_style()}

    </head>

    <body>

        <h1>
            PriviScan Analysis
        </h1>

        <p class="subtitle">
            Privacy Risk Assessment
        </p>

        <div class="card summary">

            <p>
                <strong>
                    File:
                </strong>

                {html.escape(original_name)}
            </p>

            <div class="risk-score {risk_css}">
                {risk_score:.2f} / 100
            </div>

            <div class="risk-level {risk_css}">
                {html.escape(risk_level)}
            </div>

            <p>
                {len(detections)}
                sensitive item(s) detected.
            </p>

        </div>

    """

    # ========================================================
    # DETECTIONS
    # ========================================================

    if detections:

        page += """
        <div class="card">

            <h2>
                Detected Sensitive Information
            </h2>

            <p class="note">
                Select the items you want to protect
                when using Manual Protection.
            </p>

            <form
                action="/protect"
                method="post"
            >

        """

        page += f"""
                <input
                    type="hidden"
                    name="filename"
                    value="{html.escape(stored_name)}"
                >
        """

        # ----------------------------------------------------
        # Detection cards
        # ----------------------------------------------------

        for index, detection in enumerate(
            detections
        ):

            detection_type = str(
                detection.get(
                    "type",
                    "UNKNOWN",
                )
            )

            value = str(
                detection.get(
                    "value",
                    "",
                )
            )

            confidence = detection.get(
                "confidence",
                None,
            )

            individual_risk = detection.get(
                "risk",
                0.0,
            )

            box = detection.get(
                "box",
                [],
            )

            if confidence is None:
                confidence_html = ""
            else:
                confidence_html = f"""
                <p>
                    <strong>
                        Confidence:
                    </strong>
                    {float(confidence):.4f}
                </p>
                """

            page += f"""
                <div class="detection">

                    <div class="detection-header">

                        <input
                            type="checkbox"
                            name="selected_ids"
                            value="{index}"
                            id="detection_{index}"
                        >

                        <label
                            for="detection_{index}"
                            class="detection-type"
                        >
                            {html.escape(detection_type)}
                        </label>

                    </div>

                    <div class="detection-value">

                        <strong>
                            Value:
                        </strong>

                        {html.escape(value)}

                    </div>

                    <p>

                        <strong>
                            Risk:
                        </strong>

                        {float(individual_risk):.2f}

                    </p>

                    {confidence_html}

                    <p>

                        <strong>
                            Box:
                        </strong>

                        {html.escape(str(box))}

                    </p>

                </div>
            """

        # ====================================================
        # PROTECTION OPTIONS
        # ====================================================

        page += f"""

                <div class="protection-box">

                    <h2>
                        Protection Options
                    </h2>

                    <p>
                        Choose how PriviScan should
                        protect the detected information.
                    </p>


                    <h3>
                        Protection Mode
                    </h3>


                    <label class="option">

                        <input
                            type="radio"
                            name="mode"
                            value="automatic"
                            checked
                        >

                        <strong>
                            Automatic Protection
                        </strong>

                        <br>

                        <span class="note">
                            Protect all detected sensitive
                            information.
                        </span>

                    </label>


                    <label class="option">

                        <input
                            type="radio"
                            name="mode"
                            value="manual"
                        >

                        <strong>
                            Manual Protection
                        </strong>

                        <br>

                        <span class="note">
                            Protect only the sensitive
                            information selected above.
                        </span>

                    </label>


                    <div class="method-box">

                        <h3>
                            Protection Method
                        </h3>


                        <select
                            name="method"
                        >

                            <option value="blur">
                                Blur
                            </option>

                            <option value="blackout">
                                Blackout
                            </option>

                        </select>

                    </div>


                    <br>

                    <button type="submit">
                        Protect Image
                    </button>

                </div>


            </form>

        </div>

        """

        # ----------------------------------------------------
        # Risk details
        # ----------------------------------------------------

        page += f"""

        <div class="card">

            <h2>
                Risk Details
            </h2>

            <p>
                <strong>
                    Combination Risk:
                </strong>

                {combination_risk:.2f}
            </p>

            <p>
                <strong>
                    Credential Critical Override:
                </strong>

                {"Yes" if critical_override else "No"}
            </p>

        </div>

        """

    else:

        page += """

        <div class="card summary">

            <h2>
                No Sensitive Information Detected
            </h2>

            <p>
                PriviScan did not identify any
                supported sensitive information.
            </p>

        </div>

        """

    # ========================================================
    # END PAGE
    # ========================================================

    page += """

        <div class="center">

            <a href="/">
                ← Analyze Another Image
            </a>

        </div>

    </body>

    </html>
    """

    return page


# ============================================================
# PROTECT IMAGE
# ============================================================

@app.post(
    "/protect",
    response_class=HTMLResponse,
)
async def protect(
    filename: str = Form(...),
    mode: str = Form(...),
    method: str = Form(...),
    selected_ids: list[int] | None = Form(None),
):

    # --------------------------------------------------------
    # Sanitize filename
    # --------------------------------------------------------

    filename = Path(
        filename
    ).name

    input_path = (
        UPLOAD_DIR
        / filename
    )

    # --------------------------------------------------------
    # Check input
    # --------------------------------------------------------

    if not input_path.exists():

        return f"""
        <!DOCTYPE html>

        <html>

        <head>
            <title>PriviScan Error</title>
            {page_style()}
        </head>

        <body>

            <div class="error">

                <h1>
                    Image Not Found
                </h1>

                <p>
                    The original image could not be found.
                </p>

                <a href="/">
                    ← Go Back
                </a>

            </div>

        </body>

        </html>
        """

    # --------------------------------------------------------
    # Validate mode
    # --------------------------------------------------------

    if mode not in {
        "automatic",
        "manual",
    }:

        return """
        <h1>
            Invalid protection mode.
        </h1>
        <a href="/">
            Go Back
        </a>
        """

    # --------------------------------------------------------
    # Validate method
    # --------------------------------------------------------

    if method not in {
        "blur",
        "blackout",
    }:

        return """
        <h1>
            Invalid protection method.
        </h1>
        <a href="/">
            Go Back
        </a>
        """

    # --------------------------------------------------------
    # Manual selection
    # --------------------------------------------------------

    if mode == "manual":

        if not selected_ids:

            return f"""
            <!DOCTYPE html>

            <html>

            <head>
                <title>PriviScan</title>
                {page_style()}
            </head>

            <body>

                <div class="error">

                    <h1>
                        No Items Selected
                    </h1>

                    <p>
                        Manual Protection requires
                        at least one sensitive item.
                    </p>

                    <a href="/">
                        ← Start Again
                    </a>

                </div>

            </body>

            </html>
            """

        selected_indices = [
            int(index)
            for index in selected_ids
        ]

    else:

        selected_indices = None

    # --------------------------------------------------------
    # Re-analyze original image
    #
    # This guarantees that protection uses the same
    # AI detection pipeline as the analysis page.
    # --------------------------------------------------------

    try:

        analysis = analyze_image(
            str(input_path)
        )

        detections = analysis.get(
            "detections",
            [],
        )

        if not detections:

            return """
            <h1>
                No Sensitive Information Found
            </h1>

            <p>
                There is nothing to protect.
            </p>

            <a href="/">
                Go Back
            </a>
            """

        # ----------------------------------------------------
        # Output filename
        # ----------------------------------------------------

        protected_name = (
            "protected_"
            + uuid4().hex[:8]
            + "_"
            + input_path.name
        )

        output_path = (
            UPLOAD_DIR
            / protected_name
        )

        # ----------------------------------------------------
        # Protect
        # ----------------------------------------------------

        result = protect_image(
            image_path=input_path,
            detections=detections,
            mode=mode,
            method=method,
            selected_indices=selected_indices,
            output_path=output_path,
        )

    except Exception as error:

        return f"""
        <!DOCTYPE html>

        <html>

        <head>
            <title>PriviScan Protection Error</title>
            {page_style()}
        </head>

        <body>

            <div class="error">

                <h1>
                    Protection Error
                </h1>

                <p>
                    {html.escape(str(error))}
                </p>

                <a href="/">
                    ← Go Back
                </a>

            </div>

        </body>

        </html>
        """

    # ========================================================
    # PROTECTED IMAGE PAGE
    # ========================================================

    protected_count = result.get(
        "protected_count",
        0,
    )

    detected_count = result.get(
        "detected_count",
        len(detections),
    )

    selected_count = result.get(
        "selected_count",
        protected_count,
    )

    return f"""
    <!DOCTYPE html>

    <html>

    <head>

        <title>
            PriviScan Protected Image
        </title>

        {page_style()}

    </head>

    <body>

        <h1>
            Protection Complete
        </h1>

        <p class="subtitle">
            Your selected sensitive information
            has been protected.
        </p>


        <div class="card summary">

            <h2>
                Protection Successful
            </h2>

            <p>
                <strong>
                    Mode:
                </strong>

                {html.escape(mode.upper())}
            </p>

            <p>
                <strong>
                    Method:
                </strong>

                {html.escape(method.upper())}
            </p>

            <p>
                <strong>
                    Detected:
                </strong>

                {detected_count}
            </p>

            <p>
                <strong>
                    Selected:
                </strong>

                {selected_count}
            </p>

            <p>
                <strong>
                    Protected:
                </strong>

                {protected_count}
            </p>

        </div>


        <div class="card image-preview">

            <h2>
                Protected Image
            </h2>

            <img
                src="/uploads/{html.escape(protected_name)}"
                alt="Protected image"
            >

            <br><br>

            <a
                href="/uploads/{html.escape(protected_name)}"
                target="_blank"
            >
                Open Protected Image
            </a>

        </div>


        <div class="center">

            <a href="/">
                ← Analyze Another Image
            </a>

        </div>

    </body>

    </html>
    """


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(
        "backend.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )