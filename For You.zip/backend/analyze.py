"""
PriviScan Complete Analysis Pipeline

Pipeline:

    Image
      ↓
    OCR
      ↓
    AI Detection
      ↓
    Context / Sector
      ↓
    Risk Engine
      ↓
    Final Analysis Result
"""

from typing import Any, Dict

from backend.ocr.detector import extract_text
from backend.detection.ai_detector import detect_with_ai
from backend.detection.context import analyze_context
from backend.risk.scoring import calculate_risk


# ============================================================
# MAIN ANALYSIS FUNCTION
# ============================================================

def analyze_image(
    image_path: str,
    exposure: str = "UNKNOWN",
) -> Dict[str, Any]:
    """
    Analyze an image using the complete PriviScan pipeline.

    Parameters:

        image_path:
            Path to uploaded image.

        exposure:
            Expected exposure level.

            Examples:
                PRIVATE
                INTERNAL
                SHARED
                PUBLIC
                UNKNOWN

    Returns:

        {
            "ocr": [...],
            "detections": [...],
            "sector": "...",
            "risk": {...}
        }
    """

    # ========================================================
    # STEP 1 — OCR
    # ========================================================

    print(
        "\n[1/4] Running OCR..."
    )

    ocr_results = extract_text(
        image_path
    )

    print(
        f"OCR detected "
        f"{len(ocr_results)} text regions."
    )

    # ========================================================
    # STEP 2 — AI DETECTION
    # ========================================================

    print(
        "\n[2/4] Running AI detection..."
    )

    detections = detect_with_ai(
        ocr_results
    )

    print(
        f"AI detected "
        f"{len(detections)} sensitive items."
    )

    # ========================================================
    # STEP 3 — CONTEXT / SECTOR
    # ========================================================

    print(
        "\n[3/4] Detecting sector/context..."
    )

    context_result = analyze_context(
        ocr_results=ocr_results,
        detections=detections,
    )

    sector = context_result.get(
        "sector",
        "UNKNOWN",
    )

    # ========================================================
    # STEP 4 — RISK ENGINE
    # ========================================================

    print(
        "\n[4/4] Calculating risk..."
    )

    risk_result = calculate_risk(
        detections=detections,
        sector=sector,
        exposure=exposure,
    )

    # ========================================================
    # FINAL RESULT
    # ========================================================

    result = {
        "image": image_path,

        "ocr": ocr_results,

        "detections": risk_result.get(
            "detections",
            [],
        ),

        "context": context_result,

        "sector": sector,

        "exposure": exposure,

        "risk": risk_result,

        "risk_score": risk_result.get(
            "risk_score",
            0.0,
        ),

        "risk_level": risk_result.get(
            "risk_level",
            "LOW",
        ),
    }

    return result


# ============================================================
# PRINT RESULT
# ============================================================

def print_analysis(
    result: Dict[str, Any]
) -> None:
    """
    Print a readable analysis report.
    """

    print(
        "\n"
        "========================================"
    )

    print(
        "          PRIVISCAN ANALYSIS"
    )

    print(
        "========================================"
    )

    # --------------------------------------------------------
    # Sector
    # --------------------------------------------------------

    print(
        f"\nSector: "
        f"{result.get('sector', 'UNKNOWN')}"
    )

    print(
        f"Exposure: "
        f"{result.get('exposure', 'UNKNOWN')}"
    )

    # --------------------------------------------------------
    # Risk
    # --------------------------------------------------------

    print(
        f"\nRisk Score: "
        f"{result.get('risk_score', 0)}"
    )

    print(
        f"Risk Level: "
        f"{result.get('risk_level', 'LOW')}"
    )

    # --------------------------------------------------------
    # Detections
    # --------------------------------------------------------

    detections = result.get(
        "detections",
        [],
    )

    print(
        f"\nDetections: "
        f"{len(detections)}"
    )

    for index, detection in enumerate(
        detections,
        start=1,
    ):

        print(
            f"\n[{index}] "
            f"{detection.get('type')}"
        )

        print(
            f"Value: "
            f"{detection.get('value')}"
        )

        print(
            f"Confidence: "
            f"{detection.get('confidence')}"
        )

        print(
            f"Risk: "
            f"{detection.get('risk')}"
        )

        print(
            f"Box: "
            f"{detection.get('box')}"
        )

        if detection.get(
            "subtype"
        ):

            print(
                f"Subtype: "
                f"{detection.get('subtype')}"
            )

    # --------------------------------------------------------
    # Combination risk
    # --------------------------------------------------------

    risk = result.get(
        "risk",
        {},
    )

    print(
        "\nCombination Risk: "
        f"{risk.get('combination_risk', 0)}"
    )

    # --------------------------------------------------------
    # Critical override
    # --------------------------------------------------------

    print(
        "Critical Override: "
        f"{risk.get('credential_override', False)}"
    )

    print(
        "\n"
        "========================================"
    )


# ============================================================
# DIRECT TEST
# ============================================================

if __name__ == "__main__":

    import sys

    if len(sys.argv) < 2:

        print(
            "Usage:"
        )

        print(
            "python -m backend.analyze "
            "<image_path>"
        )

        sys.exit(1)

    image_path = sys.argv[1]

    result = analyze_image(
        image_path=image_path,
        exposure="UNKNOWN",
    )

    print_analysis(
        result
    )