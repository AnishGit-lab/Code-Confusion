# backend/detection/ai_detector.py

from pathlib import Path
from difflib import SequenceMatcher
import re

from backend.ocr.detector import extract_text


# ============================================================
# MODEL CONFIGURATION
# ============================================================

MODEL_NAME = "urchade/gliner_small-v2.1"


# ============================================================
# SUPPORTED SENSITIVE DATA TYPES
# ============================================================

SUPPORTED_TYPES = {
    "NAME",
    "EMAIL",
    "PHONE",
    "ADDRESS",
    "ID",
    "GOVERNMENT_ID",
    "ACCOUNT_NUMBER",
    "BANK_CARD",
    "PASSWORD",
    "API_KEY",
    "SECRET",
}


# ============================================================
# GLiNER LABELS
# ============================================================

AI_LABELS = [
    "person name",
    "email address",
    "phone number",
    "physical address",
    "identification number",
    "government identification number",
    "account number",
    "bank card number",
    "password",
    "API key",
    "secret",
]


LABEL_MAPPING = {
    "person name": "NAME",
    "name": "NAME",

    "email address": "EMAIL",
    "email": "EMAIL",

    "phone number": "PHONE",
    "phone": "PHONE",
    "telephone number": "PHONE",

    "physical address": "ADDRESS",
    "address": "ADDRESS",

    "identification number": "ID",
    "id number": "ID",
    "identification": "ID",

    "government identification number": "GOVERNMENT_ID",
    "government id": "GOVERNMENT_ID",
    "government identification": "GOVERNMENT_ID",

    "account number": "ACCOUNT_NUMBER",
    "account": "ACCOUNT_NUMBER",

    "bank card number": "BANK_CARD",
    "bank card": "BANK_CARD",
    "card number": "BANK_CARD",

    "password": "PASSWORD",

    "api key": "API_KEY",
    "api_key": "API_KEY",
    "api token": "API_KEY",

    "secret": "SECRET",
    "secret key": "SECRET",
}


# ============================================================
# FIELD LABELS
# ============================================================

FIELD_LABELS = {
    "NAME": [
        "name",
        "full name",
        "person name",
        "customer name",
        "student name",
        "employee name",
    ],

    "EMAIL": [
        "email",
        "email address",
        "e-mail",
    ],

    "PHONE": [
        "phone",
        "phone number",
        "mobile",
        "mobile number",
        "telephone",
        "telephone number",
        "contact number",
    ],

    "ADDRESS": [
        "address",
        "home address",
        "street address",
        "residential address",
        "location",
    ],

    "ID": [
        "id",
        "id number",
        "identification number",
        "student id",
        "student number",
        "employee id",
        "employee number",
        "staff id",
        "staff number",
        "faculty id",
        "faculty number",
        "member id",
        "member number",
        "membership id",
        "membership number",
    ],

    "GOVERNMENT_ID": [
        "government id",
        "government identification",
        "government identification number",
        "passport",
        "passport number",
        "driver license",
        "driver license number",
        "driving license",
        "resident card",
        "resident card number",
    ],

    "ACCOUNT_NUMBER": [
        "account",
        "account number",
        "account information",
        "bank account",
        "bank account number",
    ],

    "BANK_CARD": [
        "card",
        "card number",
        "bank card",
        "bank card number",
        "credit card",
        "credit card number",
        "debit card",
        "debit card number",
    ],

    "PASSWORD": [
        "password",
        "passcode",
        "pass code",
        "login password",
    ],

    "API_KEY": [
        "api key",
        "api token",
        "access token",
        "authentication token",
        "auth token",
        "secret key",
    ],

    "SECRET": [
        "secret",
        "secret value",
        "secret key",
        "private key",
        "credential",
    ],
}


# ============================================================
# REGEX
# ============================================================

EMAIL_PATTERN = re.compile(
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"
)


# ============================================================
# NORMALIZATION
# ============================================================

def normalize_text(value):
    """
    Normalize text for comparison.
    """

    if value is None:
        return ""

    value = str(value).strip().lower()
    value = re.sub(r"\s+", " ", value)

    return value


def normalize_label(value):
    """
    Normalize a field label for fuzzy matching.
    """

    value = normalize_text(value)

    value = re.sub(
        r"[^a-z0-9 ]",
        "",
        value,
    )

    return value


# ============================================================
# VALIDATION
# ============================================================

def is_valid_email(value):
    """
    Check whether a value is an email address.
    """

    if not value:
        return False

    return bool(
        EMAIL_PATTERN.search(value)
    )


def is_numeric_identifier(value):
    """
    Generic numeric identifier validation.
    """

    if not value:
        return False

    digits = re.sub(
        r"\D",
        "",
        value,
    )

    return len(digits) >= 5


def is_probable_bank_card(value):
    """
    Basic bank-card validation.
    """

    if not value:
        return False

    digits = re.sub(
        r"\D",
        "",
        value,
    )

    return 13 <= len(digits) <= 19


def is_probable_api_key(value):
    """
    Check for common API-key/token prefixes.
    """

    if not value:
        return False

    value_lower = value.lower()

    prefixes = (
        "sk-",
        "pk-",
        "api-",
        "key-",
        "token-",
        "ghp_",
        "github_pat_",
        "xoxb-",
        "xoxp-",
        "bearer ",
    )

    return value_lower.startswith(prefixes)


# ============================================================
# FIELD LABEL DETECTION
# ============================================================

def detect_field_type(label):
    """
    Fuzzy-match an OCR field label to a sensitive type.

    Example:

        API Key
        API Kev

    both resolve to API_KEY.
    """

    normalized = normalize_label(label)

    if not normalized:
        return None

    best_type = None
    best_score = 0.0

    for sensitive_type, possible_labels in FIELD_LABELS.items():

        for possible_label in possible_labels:

            candidate = normalize_label(
                possible_label
            )

            score = SequenceMatcher(
                None,
                normalized,
                candidate,
            ).ratio()

            if score > best_score:
                best_score = score
                best_type = sensitive_type

    if best_score >= 0.78:
        return best_type

    return None


# ============================================================
# FIELD/VALUE SPLITTING
# ============================================================

def split_field_value(text):
    """
    Split:

        Email: anish@example.com

    into:

        Email
        anish@example.com
    """

    if not text:
        return None, None

    if ":" not in text:
        return None, None

    label, value = text.split(
        ":",
        1,
    )

    label = label.strip()
    value = value.strip()

    if not label or not value:
        return None, None

    return label, value


# ============================================================
# LABELED VALUE DETECTION
# ============================================================

def detect_labeled_values(ocr_results):

    detections = []

    for item in ocr_results:

        text = str(
            item.get("text", "")
        ).strip()

        confidence = float(
            item.get(
                "confidence",
                0.0,
            )
        )

        box = item.get("box")

        label, value = split_field_value(
            text
        )

        if not label or not value:
            continue

        sensitive_type = detect_field_type(
            label
        )

        if not sensitive_type:
            continue

        # EMAIL
        if sensitive_type == "EMAIL":

            if not is_valid_email(value):
                continue

        # PHONE
        elif sensitive_type == "PHONE":

            digits = re.sub(
                r"\D",
                "",
                value,
            )

            if len(digits) < 7:
                continue

        # ID
        elif sensitive_type == "ID":

            if not is_numeric_identifier(value):
                continue

        # GOVERNMENT ID
        elif sensitive_type == "GOVERNMENT_ID":

            if len(value) < 4:
                continue

        # ACCOUNT NUMBER
        elif sensitive_type == "ACCOUNT_NUMBER":

            if not is_numeric_identifier(value):
                continue

        # BANK CARD
        elif sensitive_type == "BANK_CARD":

            if not is_probable_bank_card(value):
                continue

        # PASSWORD
        elif sensitive_type == "PASSWORD":

            if len(value) < 4:
                continue

        # API KEY
        elif sensitive_type == "API_KEY":

            if len(value) < 4:
                continue

        # SECRET
        elif sensitive_type == "SECRET":

            if len(value) < 4:
                continue

        # NAME
        elif sensitive_type == "NAME":

            if len(value) < 2:
                continue

        # ADDRESS
        elif sensitive_type == "ADDRESS":

            if len(value) < 4:
                continue

        detection_confidence = max(
            0.85,
            min(
                0.99,
                confidence,
            ),
        )

        detections.append(
            {
                "type": sensitive_type,
                "value": value,
                "confidence": round(
                    detection_confidence,
                    4,
                ),
                "box": box,
                "source": "field_label",
            }
        )

    return detections


# ============================================================
# ACCOUNT CONTEXT DETECTION
# ============================================================

def detect_account_from_context(
    ocr_results
):

    detections = []

    for index, item in enumerate(
        ocr_results
    ):

        text = str(
            item.get(
                "text",
                "",
            )
        ).strip()

        if not text:
            continue

        label_type = detect_field_type(
            text
        )

        if label_type != "ACCOUNT_NUMBER":
            continue

        if index + 1 >= len(
            ocr_results
        ):
            continue

        next_item = ocr_results[
            index + 1
        ]

        value = str(
            next_item.get(
                "text",
                "",
            )
        ).strip()

        if not is_numeric_identifier(
            value
        ):
            continue

        detections.append(
            {
                "type": "ACCOUNT_NUMBER",
                "value": value,
                "confidence": 0.98,
                "box": next_item.get(
                    "box"
                ),
                "source": "account_context",
            }
        )

    return detections


# ============================================================
# GLiNER AI DETECTION
# ============================================================

def detect_with_gliner(
    ocr_results
):

    detections = []

    try:
        from gliner import GLiNER

    except ImportError:

        print(
            "WARNING: GLiNER is not installed."
        )

        return detections

    try:

        model = GLiNER.from_pretrained(
            MODEL_NAME
        )

    except Exception as exc:

        print(
            f"WARNING: Could not load "
            f"GLiNER model: {exc}"
        )

        return detections

    for item in ocr_results:

        text = str(
            item.get(
                "text",
                "",
            )
        ).strip()

        if not text:
            continue

        ocr_confidence = float(
            item.get(
                "confidence",
                0.0,
            )
        )

        box = item.get(
            "box"
        )

        # ----------------------------------------------------
        # IMPORTANT FIELD CONTEXT
        # ----------------------------------------------------
        #
        # If OCR has:
        #
        #     API Kev: sk-test-123456789
        #
        # GLiNER may incorrectly identify "Kev"
        # as a NAME.
        #
        # Therefore we first determine whether the
        # region contains a recognized field label.
        #
        # ----------------------------------------------------

        field_label = None
        field_type = None

        if ":" in text:

            field_label = text.split(
                ":",
                1,
            )[0].strip()

            field_type = detect_field_type(
                field_label
            )

        try:

            entities = model.predict_entities(
                text,
                AI_LABELS,
                threshold=0.55,
            )

        except Exception as exc:

            print(
                f"WARNING: GLiNER prediction "
                f"failed for '{text}': {exc}"
            )

            continue

        for entity in entities:

            raw_label = normalize_text(
                entity.get(
                    "label",
                    "",
                )
            )

            sensitive_type = LABEL_MAPPING.get(
                raw_label
            )

            if not sensitive_type:
                continue

            value = str(
                entity.get(
                    "text",
                    "",
                )
            ).strip()

            if not value:
                continue

            # =================================================
            # CRITICAL FIELD-CONTEXT PROTECTION
            # =================================================
            #
            # If the OCR region already contains a recognized
            # field label, don't let GLiNER classify pieces of
            # that field label as another sensitive type.
            #
            # Example:
            #
            # API Kev: sk-test-123456789
            #
            # "Kev" must NOT become NAME.
            #
            # Password: MySecretPassword123
            #
            # The password value must NOT become API_KEY.
            #
            # =================================================

            if field_type is not None:

                # The entire region already has a known
                # semantic field.
                #
                # Only allow the field's intended type.

                if sensitive_type != field_type:

                    continue

            # =================================================
            # EMAIL -> never NAME
            # =================================================

            if sensitive_type == "NAME":

                if "@" in value:
                    continue

                if is_valid_email(text):
                    continue

            # =================================================
            # EMAIL VALIDATION
            # =================================================

            if sensitive_type == "EMAIL":

                if not is_valid_email(value):
                    continue

            # =================================================
            # ACCOUNT VALIDATION
            # =================================================

            if sensitive_type == "ACCOUNT_NUMBER":

                if not is_numeric_identifier(
                    value
                ):
                    continue

            # =================================================
            # BANK CARD VALIDATION
            # =================================================

            if sensitive_type == "BANK_CARD":

                if not is_probable_bank_card(
                    value
                ):
                    continue

            # =================================================
            # ID VALIDATION
            # =================================================

            if sensitive_type == "ID":

                if not is_numeric_identifier(
                    value
                ):
                    continue

            entity_score = float(
                entity.get(
                    "score",
                    0.0,
                )
            )

            confidence = max(
                0.0,
                min(
                    0.99,
                    (
                        entity_score
                        + ocr_confidence
                    )
                    / 2,
                ),
            )

            detections.append(
                {
                    "type": sensitive_type,
                    "value": value,
                    "confidence": round(
                        confidence,
                        4,
                    ),
                    "box": box,
                    "source": "gliner",
                }
            )

    return detections


# ============================================================
# DEDUPLICATION
# ============================================================

def deduplicate_detections(
    detections
):

    best = {}

    for detection in detections:

        dtype = detection.get(
            "type"
        )

        value = str(
            detection.get(
                "value",
                "",
            )
        ).strip()

        if not dtype or not value:
            continue

        key = (
            dtype,
            normalize_text(value),
        )

        confidence = float(
            detection.get(
                "confidence",
                0.0,
            )
        )

        if key not in best:

            best[key] = detection

            continue

        old_confidence = float(
            best[key].get(
                "confidence",
                0.0,
            )
        )

        if confidence > old_confidence:

            best[key] = detection

    return list(
        best.values()
    )


# ============================================================
# CONFLICT CLEANUP
# ============================================================

def clean_conflicting_detections(
    detections
):
    """
    Remove semantic conflicts.

    EMAIL > NAME

    PASSWORD > API_KEY / SECRET
    """

    cleaned = []

    email_values = {
        normalize_text(
            detection.get(
                "value",
                "",
            )
        )
        for detection in detections
        if detection.get(
            "type"
        ) == "EMAIL"
    }

    password_values = {
        normalize_text(
            detection.get(
                "value",
                "",
            )
        )
        for detection in detections
        if detection.get(
            "type"
        ) == "PASSWORD"
    }

    for detection in detections:

        dtype = detection.get(
            "type"
        )

        value = str(
            detection.get(
                "value",
                "",
            )
        ).strip()

        normalized_value = normalize_text(
            value
        )

        # ====================================================
        # EMAIL USERNAME -> NOT NAME
        # ====================================================

        if dtype == "NAME":

            if "@" in value:
                continue

            is_email_username = False

            for email in email_values:

                if "@" not in email:
                    continue

                username = email.split(
                    "@",
                    1,
                )[0]

                if normalized_value == normalize_text(
                    username
                ):

                    is_email_username = True
                    break

            if is_email_username:
                continue

        # ====================================================
        # PASSWORD -> NOT API_KEY/SECRET
        # ====================================================

        if dtype in {
            "API_KEY",
            "SECRET",
        }:

            if (
                normalized_value
                in password_values
            ):
                continue

        cleaned.append(
            detection
        )

    return cleaned


# ============================================================
# FINAL VALIDATION
# ============================================================

def final_validate_detections(
    detections
):

    validated = []

    for detection in detections:

        dtype = detection.get(
            "type"
        )

        value = str(
            detection.get(
                "value",
                "",
            )
        ).strip()

        if dtype not in SUPPORTED_TYPES:
            continue

        if not value:
            continue

        # EMAIL
        if dtype == "EMAIL":

            if not is_valid_email(
                value
            ):
                continue

        # PHONE
        elif dtype == "PHONE":

            digits = re.sub(
                r"\D",
                "",
                value,
            )

            if len(digits) < 7:
                continue

        # BANK CARD
        elif dtype == "BANK_CARD":

            if not is_probable_bank_card(
                value
            ):
                continue

        # ACCOUNT
        elif dtype == "ACCOUNT_NUMBER":

            if not is_numeric_identifier(
                value
            ):
                continue

        # ID
        elif dtype == "ID":

            if not is_numeric_identifier(
                value
            ):
                continue

        validated.append(
            detection
        )

    return validated


# ============================================================
# MAIN OCR -> AI PIPELINE
# ============================================================

def detect_from_ocr(
    ocr_results
):
    """
    Main sensitive-data detection pipeline.

    OCR
      ↓
    Field-label detection
      ↓
    Account context detection
      ↓
    GLiNER AI
      ↓
    Deduplication
      ↓
    Conflict cleanup
      ↓
    Final validation
    """

    if not ocr_results:
        return []

    detections = []

    # --------------------------------------------------------
    # 1. Explicit field labels
    # --------------------------------------------------------

    detections.extend(
        detect_labeled_values(
            ocr_results
        )
    )

    # --------------------------------------------------------
    # 2. Account context
    # --------------------------------------------------------

    detections.extend(
        detect_account_from_context(
            ocr_results
        )
    )

    # --------------------------------------------------------
    # 3. GLiNER
    # --------------------------------------------------------

    detections.extend(
        detect_with_gliner(
            ocr_results
        )
    )

    # --------------------------------------------------------
    # 4. Deduplicate
    # --------------------------------------------------------

    detections = deduplicate_detections(
        detections
    )

    # --------------------------------------------------------
    # 5. Conflict cleanup
    # --------------------------------------------------------

    detections = clean_conflicting_detections(
        detections
    )

    # --------------------------------------------------------
    # 6. Final validation
    # --------------------------------------------------------

    detections = final_validate_detections(
        detections
    )

    # --------------------------------------------------------
    # 7. Sort according to image position
    # --------------------------------------------------------

    detections.sort(
        key=lambda detection: (
            detection.get(
                "box",
                [0, 0, 0, 0],
            )[1]
            if detection.get("box")
            else 0,

            detection.get(
                "box",
                [0, 0, 0, 0],
            )[0]
            if detection.get("box")
            else 0,
        )
    )

    return detections


# ============================================================
# PUBLIC AI DETECTOR
# ============================================================

def detect_with_ai(
    input_data
):
    """
    Accept either:

        1. Image path

    or:

        2. Existing OCR result list
    """

    # --------------------------------------------------------
    # Existing OCR results
    # --------------------------------------------------------

    if isinstance(
        input_data,
        list,
    ):

        return detect_from_ocr(
            input_data
        )

    # --------------------------------------------------------
    # Image path
    # --------------------------------------------------------

    if isinstance(
        input_data,
        (str, Path),
    ):

        image_path = str(
            input_data
        )

        ocr_results = extract_text(
            image_path
        )

        return detect_from_ocr(
            ocr_results
        )

    raise TypeError(
        "detect_with_ai() expects "
        "an image path or OCR result list."
    )


# ============================================================
# OUTPUT
# ============================================================

def print_sensitive_data(
    detections
):

    print()
    print("=" * 40)
    print("       SENSITIVE DATA ONLY")
    print("=" * 40)

    if not detections:

        print()
        print(
            "No sensitive data detected."
        )

        return

    print()

    for index, detection in enumerate(
        detections,
        start=1,
    ):

        print(
            f"[{index}] "
            f"{detection.get('type')}"
        )

        print(
            f"Value: "
            f"{detection.get('value')}"
        )

        print(
            f"Confidence: "
            f"{detection.get('confidence')}"
        )

        print(
            f"Box: "
            f"{detection.get('box')}"
        )

        print()


# ============================================================
# TEST
# ============================================================

def main():

    image_path = Path(
        "dataset/mixed/info.png"
    )

    if not image_path.exists():

        print(
            f"ERROR: Image not found: "
            f"{image_path}"
        )

        return

    print()
    print(
        f"Analyzing image: "
        f"{image_path}"
    )

    detections = detect_with_ai(
        image_path
    )

    print_sensitive_data(
        detections
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    main()